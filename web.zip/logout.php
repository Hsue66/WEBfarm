<?

include "lib.php";

unset($_SESSION['id']);
unset($_SESSION['name']);


     echo "<script> alert('로그아웃 되었습니다...');</script>";
     echo "<script language='javascript'>history.back();";
	 echo "</script>";

?>


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
</body>
</html>